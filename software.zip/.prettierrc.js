module.exports = {
	semi: false,
	singleQuote: true,
	printWidth: 150,
	tabWidth: 2,
	endOfLine: 'auto',
	useTabs: true,
	trailingComma: 'none',
	jsxBracketSameLine: true,
	bracketSpacing: true,
	eslintIntegration: true
}
